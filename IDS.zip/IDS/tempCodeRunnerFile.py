
model.add(Dense(38, activation='softmax'))  # Update the number of units